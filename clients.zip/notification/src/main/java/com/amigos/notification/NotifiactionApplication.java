package com.amigos.notification;

public class NotifiactionApplication {
}
