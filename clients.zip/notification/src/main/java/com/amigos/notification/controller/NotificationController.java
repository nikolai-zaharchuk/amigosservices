package com.amigos.notification.controller;

import com.amigos.clients.fraud.dto.request.NotificationRequest;
import com.amigos.clients.fraud.dto.response.NotificationResponse;
import com.amigos.notification.service.NotificationService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("api/notification")
@AllArgsConstructor
public class NotificationController {
    private final NotificationService notificationService;
    @PostMapping
    public NotificationResponse sendNotification(
            @RequestBody NotificationRequest notificationRequest
            ) {
        return notificationService.sendNotification(notificationRequest);
    }
}
