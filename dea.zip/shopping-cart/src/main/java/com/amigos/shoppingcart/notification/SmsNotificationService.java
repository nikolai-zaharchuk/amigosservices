package com.amigos.shoppingcart.notification;

import org.springframework.stereotype.Service;

@Service
public class SmsNotificationService implements NotificationService{
    @Override
    public void send(String message) {
        System.out.println("Send by SMS");
    }
}
