package com.amigos.clients.fraud.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FraudCheckResponse {
    private Boolean fraudster;

    public boolean isFraudster() {
        return fraudster;
    }
}
