package com.amigos.notification.dao;

public interface NotificationDao {
    void addNotification();
}
