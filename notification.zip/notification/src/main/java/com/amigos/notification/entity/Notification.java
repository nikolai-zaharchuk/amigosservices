package com.amigos.notification.entity;

public class Notification {
}
