package com.amigos.notification.repository;

public class NotificationRepository {
}
