package com.amigos.notification.service.access;

import com.amigos.notification.dao.NotificationDao;
import org.springframework.stereotype.Service;

@Service
public class NotificationDaoAccessService implements NotificationDao {
    @Override
    public void addNotification() {

    }
}
